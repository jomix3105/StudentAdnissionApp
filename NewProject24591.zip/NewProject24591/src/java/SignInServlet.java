import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class SignInServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Authenticate user based on email and password
        // For simplicity, you can check against hard-coded values or a database
        
        if (email.equals("example@example.com") && password.equals("password")) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            response.sendRedirect("admission.jsp");
        } else {
            // Invalid credentials, redirect back to sign in page
            response.sendRedirect("signin.jsp");
        }
    }
}
