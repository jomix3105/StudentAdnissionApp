import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class SignUpServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Save email and password to database or any storage

        // Redirect to SignIn page
        response.sendRedirect("signin.jsp");
    }
}
