import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/AdmissionServlet")
public class AdmissionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String dob = request.getParameter("dob");
        String address = request.getParameter("address");
        String phoneNumber = request.getParameter("phoneNumber");
        String gender = request.getParameter("gender");

        // Handle file uploads
        Part passportPart = request.getPart("passport");
        Part diplomaPart = request.getPart("diploma");

        // Save uploaded files to a directory
        /*String passportFileName = getSubmittedFileName(passportPart);
        String diplomaFileName = getSubmittedFileName(diplomaPart);

        String uploadPath = "C:/"; // 
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }

        String passportFilePath = uploadPath + File.separator + passportFileName;
        String diplomaFilePath = uploadPath + File.separator + diplomaFileName;

        passportPart.write(passportFilePath);
        diplomaPart.write(diplomaFilePath);*/

        // Here you can process the form data and file paths further 

        // Redirect or forward to a success page
        response.sendRedirect("success.jsp");
    }

    /*private String getSubmittedFileName(Part part) {
        String header = part.getHeader("content-disposition");
        String[] elements = header.split(";");
        for (String element : elements) {
            if (element.trim().startsWith("filename")) {
                return element.substring(element.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return null;
    }*/
}
